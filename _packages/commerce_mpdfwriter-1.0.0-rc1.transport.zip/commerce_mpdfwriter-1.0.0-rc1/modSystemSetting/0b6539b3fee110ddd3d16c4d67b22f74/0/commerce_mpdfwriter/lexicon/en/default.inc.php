<?php

$_lang['commerce_mpdfwriter'] = 'mPDFWriter';
$_lang['commerce_mpdfwriter.description'] = 'Adds a PDF Writer that Commerce can use to generate PDFs (like invoices), based on the mPDF 8.x library.';
$_lang['commerce_mpdfwriter.module_description'] = 'Adds a PDF Writer that Commerce can use to generate PDFs (like invoices), based on the mPDF 8.x library.';